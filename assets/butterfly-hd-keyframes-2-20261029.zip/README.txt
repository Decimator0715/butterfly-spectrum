HD keyframes, 3600 x 1800 pixels. Original MATLAB calculations; zero-coupling rank continuation. Files show the current flux and principal target gaps. No interpolation of physical band edges.
