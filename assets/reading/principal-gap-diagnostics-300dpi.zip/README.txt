Corrected principal-gap diagnostic stills, 29 October 2026. 300 DPI export.
18 PNGs: orders 1, 2, 3; alpha = 1/2, 1/3, 1/4, 1/5, 1/6, 3/7.
These are diagnostic stills preceding the final HD video styling, not decoded video frames.
Small-denominator targets that close, fold to lower order, or have r=0 are excluded.
The zero-coupling rank branches and original physical energies are retained.
